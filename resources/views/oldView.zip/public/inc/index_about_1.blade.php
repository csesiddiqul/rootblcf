<!-- Why Choose Us Start-->
<div class="rs-why-choose sec-spacer divide">
    <div class="container" style="max-width: 100%">
        <div class="row">
            <div class="col-md-9">
                @php $limit=1700; @endphp
                @if(school('country')->code == 'BD')
                    @php $limit=950; @endphp
                    <div style="margin-bottom: 30px">
                        <img src="{{asset('img/National-Portal-Card-PM.jpeg')}}"
                             class="img-responsive" alt="">
                    </div>
                @endif
                <div class="pull-left">
                    <div class="sec-title">
                        <h2>@lang(foqas_setting('home_atitle'))</h2>
                    </div>
                    @if(school('country')->code != 'BD')
                        @empty(!foqas_setting('about_pic'))
                            <div class="choose-img" style="{{useragentMobile() == false ? '' : 'padding:0px'}}">
                                <img src="{{foqas_setting('about_pic')}}" style="border-radius: 5px;"
                                     alt="{{foqas_setting('home_atitle')}}">
                            </div>
                        @endempty
                    @endif
                    <div class="choose-desc text-justify">
                        {!! \Illuminate\Support\Str::limit(nl2br(school('about')),$limit) !!}
                        @if(strlen(nl2br(school('about'))) > $limit)
                            <a class="text-center small d-block blue-text pb-2 pull-right"
                               href="{{url('/about')}}"><i class="fa fa-arrow-right"></i> @lang('See more') </a>
                        @endif
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                @if(school('country')->code == 'BD')
                <div class="col-lg-12 mb-2">
                    <h4 class="org-title text-white  py-1 px-1"> @lang('Golden Jubilee of Independence')</h4>
                    <div class="text-left" style="border: 2px solid {{foqas_setting('theme_bg')}};">
                        <a href="https://shed.portal.gov.bd/sites/default/files/files/shed.portal.gov.bd/npfblock/%E0%A6%AC%E0%A6%B0%E0%A7%8D%E0%A6%B7%E0%A7%87%20%E0%A6%95%E0%A6%B0%E0%A7%8D%E0%A6%AE%E0%A6%AA%E0%A6%B0%E0%A6%BF%E0%A6%95%E0%A6%B2%E0%A7%8D%E0%A6%AA%E0%A6%A8%E0%A6%BE1.pdf">
                            <img alt="" src="{{asset('img/SubarnaJoyanti.png')}}" style="width:100%">
                        </a>
                    </div>
                </div>
                @endif
                @foreach($message_menus as $menu)
                    <div class="{{useragentMobile() == false ? 'col-lg-12' : ''}} dece-head my-2">
                        <h4 class="org-title text-white  py-1 px-1"> {{transMsg($menu->name)}} </h4>
                        <div class="text-left" style="border: 2px solid {{foqas_setting('theme_bg')}};display: inline-block">
                            <a href="{{url($menu->slug)}}">
                                <img alt="" src="{{$menu->content->image}}" style="width:100%">
                            </a>
                            <h6 style="text-align:center"><span style="font-size:16px">{{$menu->content->title}}</span>
                            </h6>
                            <p> {!! \Illuminate\Support\Str::limit(nl2br($menu->content->description),40) !!}&nbsp;</p>
                            <p class="org-buttom"><a class="text-center small d-block blue-text"
                                  href="{{url($menu->slug)}}"><i class="fa fa-arrow-right"></i> @lang('See more')
                                </a></p>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
</div>
<!-- Why Choose Us End -->
