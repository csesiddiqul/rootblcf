
<div class="book_preload ">
    <div class="book">
        <img src="{{asset('image/gpLoader.gif')}}" alt="">
    </div>
</div>
{{--<div class="loader">
    <img src="{{asset('gpLoader.gif')}}" class="loader-gif" />
</div>--}}