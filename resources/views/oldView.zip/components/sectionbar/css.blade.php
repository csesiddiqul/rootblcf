<style>
    .new_b .btn:active, .btn-group .btn.active, .new_b .btnModal.btn:active, .btnModal.btn-group .btnModal.btn.active {
        box-shadow: none !important;
        border-radius: 0;
        border-bottom: 2px solid #0077f7 !important; 
        color: #0077f7;
        font-size: 14.5px;
    }

    .new_b a.btn, .new_b .btnModal.btn {
        border: none;
        background: none;
        padding: 10px 15px;
        cursor: pointer;
        float: left;
        font-size: 14.5px;
    }

    .new_b .btn:hover, .new_b .btnModal.btn:hover {
        color: #282828 !important;
    }

    .new_b a {
        font-family: sans-serif;
        font-size: 14.5px;
    }

    /*.btn-group > .btn:first-child {
        padding-left: 0px;
    }*/
</style>