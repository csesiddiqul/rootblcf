<div class="panel-body">
    <div class="btn-group new_b" style="overflow: hidden;">
        <a href="#"><button class="btn ">@lang('View Teachers')</button></a>
        <a href="#"><button class="btn " id="changeGreen">@lang('Add Teachers')</button></a>
        <a href="#"><button class="btn " id="changeGreen">@lang('View Staff')</button></a>
        <a href="#"><button class="btn " id="changeGreen">@lang('Add Staff')</button></a>
    
    </div>
</div>