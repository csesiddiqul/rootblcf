@if(Auth::user()->role == 'admin' || Auth::user()->role == 'accountant')
	<div class="panel-body pad-bot-top" >
		<div class="btn-group new_b pull-left" style="overflow: hidden; font-weight: bolder;">

			<a style="font-weight: bold" href="{{url('users/'.Auth::user()->school->code.'/accountant')}}" class="btn {{(\Request::url() == url('users/'.Auth::user()->school->code.'/accountant'))? 'active':''}}">@lang('Accountant List')</a>

			<a style="font-weight: bold" href="{{ route('accounts.financialyear.index') }}" class="btn {{(\Route::current()->getName() == 'accounts.financialyear.index')? 'active':''}}">@lang('Financial Year')</a>
			<a style="font-weight: bold" href="{{ url('accounts/ledger') }}" class="btn {{(\Request::url() == url('accounts/ledger'))? 'active':''}}">@lang('Ledger')</a>
			<a style="font-weight: bold" href="{{ url('accounts/sectors') }}" class="btn {{(\Request::url() == url('accounts/sectors'))? 'active':''}}">@lang('Accounts Head')</a>

			<a style="font-weight: bold" href="{{ route('fees.index') }}" class="btn {{(\Route::current()->getName() == 'fees.index') ? 'active':''}}">@lang('Fees')</a>

			<a style="font-weight: bold" href="{{ route('accounts.moneyreceipt') }}" class="btn {{(\Route::current()->getName() == 'accounts.moneyreceipt')? 'active':''}}">@lang('Received')</a>

			<a style="font-weight: bold" href="{{ route('accounts.expense.index') }}" class="btn {{(\Route::current()->getName() == route('accounts.expense.index'))? 'active':''}}">@lang('Expenses')</a>

			<a style="font-weight: bold" href="{{ route('accounts.duereport') }}" class="btn {{(\Route::current()->getName() == 'accounts.duereport')? 'active':''}}">@lang('All Reports')</a>

		</div>
		<div class="pull-right">
			@if(\Route::current()->getName() == 'fees.index')
				<a href="{{ route('fees.create')  }}" class="btn btn-sm foqas-btn pull-left">@lang('Add Fees')</a>
			@endif
            @if (isset($fee))
				<div class="">
					<span class="btn btn-default btn-sm pull-right" onclick="printDiv()">@lang('Print')</span>
				</div>
            @endif
            @if (isset($expenses))
					<a href="{{ route('accounts.expense.create')  }}" class="btn btn-sm foqas-btn pull-left">@lang('Add Expense')</a>
            @endif
		</div>
	</div>
@endif
@push('script')
    <script>
		@if(request()->segment(2) != 'financialyear')
			@empty(current_financial_year())
			Swal.fire({
				title: 'There is no current financial year. Activate or create an financial year.',
				icon: 'info',
			  //  timer: 2000,
				showConfirmButton: true,
			 //   timerProgressBar: true
			});
			@endempty
		@endif
    </script>
@endpush
