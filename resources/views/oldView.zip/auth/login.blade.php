@extends('layouts.app',['title' => transMsg('Login') ])
@section('content')
    <style>
        .sin_btn {
            background: #55acee !important;
            color: #363738 !important;
            width: 100%;
            border: 1px solid #cccccc94 !important;
        }

        .stage .btn {
            background: #fff !important;
            color: #5f6368 !important;
        }

        .heading h2 {
            font-size: 22px !important;
        }

        .posi {
            padding-left: 0px !important;
        }

        .stage .btn:hover {
            background-color: none !important;
            box-shadow: none !important;
        }

        .sin_btn .btn:hover {
            background-color: #4a9fd7 !important;
            box-shadow: none !important;
        }

        .sin_btn:focus {
            outline: none !important;

        }

        @media (max-width: 425px) and (min-width: 320px) {
            #registry .signup-classic {
                padding: 5px 30px !important;
            }
        }
        mt-0{
            margin-bottom: 0px;
        }
    </style>
    <!-- Start -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/css/intlTelInput.min.css"/>
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Schoolbell"/>
    <link rel="stylesheet" href="{{asset('css/custome.css')}}">
    <!-- partial:index.partial.html -->
    <div id="registry" class="signup">
        <div class="signup-connect">
            <h1>@lang('Welcome to')<br>   @if (foqas_setting('logo_type') == 1) {{transMsg(school('short_name') ?? school('name'))}}   @endif</h1>
            @if (foqas_setting('logo_type') == 1)
                @php $logo = foqas_setting('express'); @endphp
            @else
                @php $logo = foqas_setting('standard'); @endphp
            @endif
            @empty($logo)
                @php $logo = 'https://trello-attachments.s3.amazonaws.com/5f4f1c974719e18dcbcac0d8/5f4f1d43a5aabf803fbf0177/745f3e08d0efb80dd69b8e5d3fd66d82/Foqas_symbol_white.png'; @endphp
            @endempty
            <div class="forSlogo">
                <img src="{{$logo}}" alt="Logo" class="logoSchool">
            </div>
            @if ($_SERVER['SERVER_NAME'] != 'foqasacademy.com' || $_SERVER['SERVER_NAME'] != 'www.foqasacademy.com')
                <a id="topback" href="{{route('public.index')}}" class="btn btn-social posi btn-back">
                    <i class="fas fa-home fa"></i>
                    @lang('Back to Home')
                </a>
            @endif
        </div>

        <div class="signup-classic heading col-sm-12">
            <h2 class=" text-center">@lang('Login to') {{transMsg(school('short_name') ?? school('name'))}}</h2>
            <form class="form-horizontal" method="POST" action="{{ route('login') }}">
                @csrf
                <fieldset>
                    <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                        <label for="email">@lang('E-mail')</label>
                        <input id="email" type="text" class="form-control" name="email"
                               value="{{ old('email') }}" required autofocus>
                        @error('email')
                        <div class="clearhight"></div>
                        <span class="help-block">
                                        <strong>{{ transMsg($message) }}</strong>
                                    </span>
                        @enderror
                        @error('phone_number')
                        <div class="clearhight"></div>
                        <span class="help-block">
                                        <strong>{{ transMsg($message) }}</strong>
                                    </span>
                        @enderror
                    </div>

                    <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                        <label for="password">@lang('Password')</label>
                        <input id="password" type="password" class="form-control" name="password" required>
                        @if ($errors->has('password'))
                            <div class="clearhight"></div>
                            <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                        @endif
                    </div>
                    <div class="form-group">
                        <div class="checkbox">
                            <label>
                                <input type="checkbox"
                                       name="remember" {{ old('remember') ? 'checked' : '' }}> @lang('Remember Me')
                            </label>
                        </div>
                    </div>
                    <div class="form-group mt-0">
                        <button type="submit"
                                class="btn btn-sm btn-default sin_btn"> @lang('Login')
                        </button>
                        {{--    <button type="submit" class="btn btn-primary">
                               @lang('Login')
                           </button>

                            <a class="btn btn-link" href="{{ route('password.request') ">
                               @lang('Forgot Your Password?')
                           </a> --}}
                    </div>
                    <div class="form-group" style="margin-top: -12px;">
                        <div class="stage">
                            <a href="{{route('login_google')}}"
                               class="ui button google-auth__button btn  sin_btn">
                                <img src="https://foqasacademy.s3.us-east-2.amazonaws.com/img/01/foqas_google.svg"
                                     alt="">
                                @lang('Sign in with Google')
                            </a>
                        </div>
                    </div>
                    <div class="text-center forg-signup" style="font-size:small;">
                        <label><a href="{{ route('password.request') }}" style="font-size:13px;">@lang('Forgot Password?')</a>
                        </label>
                        {{--<label class="xs-hidde">&nbsp;&nbsp;||&nbsp;&nbsp;</label><label><a href="#" style="">Create New Ledger</a></label>      --}}
                    </div>
                </fieldset>
            </form>

            <a id="bottomback" href="{{route('public.index')}}" class="btn btn-social btn-back">
                <i class="fas fa-home fa"></i>
                @lang('Back')
            </a>
        </div>

    </div>
    <!-- partial -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/js/intlTelInput.min.js"></script>
    <!-- End-->

    {{--<div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2" id="main-container">
                <div class="panel panel-default">
                    <div class="page-panel-title">@lang('Login')</div>

                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <div class="panel-body">
                        <form class="form-horizontal" method="POST" action="{{ route('login') }}">
                            {{ csrf_field() }}

                            <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                                <label for="email" class="col-md-4 control-label">@lang('E-Mail Or Phone Number')</label>

                                <div class="col-md-6">
                                    <input id="email" type="text" class="form-control" name="email" value="{{ old('email') }}" required autofocus>

                                    @if ($errors->has('email'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('email') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                                <label for="password" class="col-md-4 control-label">@lang('Password')</label>

                                <div class="col-md-6">
                                    <input id="password" type="password" class="form-control" name="password" required>

                                    @if ($errors->has('password'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('password') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}> @lang('Remember Me')
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-8 col-md-offset-4">
                                    <button type="submit" class="btn btn-primary">
                                        @lang('Login')
                                    </button>

                                    <a class="btn btn-link" href="{{ route('password.request') }}">
                                        @lang('Forgot Your Password?')
                                    </a>
                                    --}}
    {{--  </div>
      </div>
      </form>
      </div>
      </div>
      </div>
      </div>
      </div>--}}
@endsection
