@extends('layouts.app')

@section('title', __('Student Fee Reports'))
@section('content')
    <style>
        h4 {
            font-size: 21px !important;
        }

        /* Chrome, Safari, Edge, Opera */
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        /* Firefox */
        input[type=number] {
            -moz-appearance: textfield;
        }
    </style>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2" id="side-navbar">
                @include('layouts.leftside-menubar')
            </div>
            <div class="col-md-10" id="main-container">
                @include('components.pages-bar',['pageTitle' =>'<a href="'. url('users/'.Auth::user()->school->code.'/accountant').'">'. trans('Manage Accounts').'</a> / <b>'.trans('Student Due Reports').'<b>'])
                @include('components.sectionbar.reports-bar')
                <div class="panel-body pl-0">
                    <div class="col-md-12 pl-0">
                        {!! Form::open(array('route' => 'accounts.studentfeereport', 'method' => 'POST', 'role' =>'form','enctype'=>'multipart/form-data', 'class' => 'needs-validation')) !!}
                        <div class="form-group col-md-2">
                            {!! Form::label('section', trans('Section'), ['class' => 'control-label']) !!}
                            {!! Form::select('section', $pluckSection , $section?? null , ['class' => 'select2 form-control','required','onchange'=>'getStudentsBySection(this.value)','placeholder'=>trans('Choose')]) !!}
                            @error('section')
                            <span class="help-block">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                        <div class="form-group col-md-2">
                            <label for="student">@lang('Student')</label>
                            {!! Form::select('student',$pluckStudent ?? array(), $student?? null, array('id' => 'student', 'class' => 'form-control select2','required','placeholder' =>trans('Choose'))) !!}
                            @error('student')
                            <span class="help-block">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>

                        <div class="form-group col-md-2">
                            <label for="head">@lang('Head')</label>
                            {!! Form::select('type',$head,$type?? null, array('id' => 'type', 'class' => 'select2 form-control','required', 'placeholder' => trans('Choose'))) !!}
                            @error('type')
                            <span class="help-block">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                        <div class="form-group col-md-2">
                            <label for="date">@lang('From')</label>
                            {!! Form::text('from', $from ?? date('01-m-Y'), array('id' => 'date', 'class' => 'form-control datepicker','autocomplete' => 'off')) !!}
                            @error('from')
                            <span class="help-block">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                        <div class="form-group col-md-2">
                            <label for="date">@lang('To')</label>
                            {!! Form::text('to', $to ?? date('t-m-Y'), array('id' => 'date', 'class' => 'form-control datepicker','autocomplete' => 'off')) !!}
                            @error('to')
                            <span class="help-block">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>

                        <div class="form-group col-md-2 mt-28 ">
                            <button type="submit" id="admitButton" class="{{btnClass()}}">
                                @lang('Search')
                            </button>
                        </div>
                        @if (isset($dues) && $dues->count())
                            <div class="col-md-1 mt-25">
                                <span class="btn btn-default btn-sm pull-right"
                                      onclick="printDiv()">@lang('Print')</span>
                            </div>
                        @endif
                        <div class="clearhight50"></div>
                        {!! Form::close() !!}
                    </div>
                    <div class="clearfix"></div>
                    @isset($dues)
                        <div id="printDiv">
                            <span class="pull-left d-print-block d-none">Print Date : <span
                                        id="printTime"></span></span>
                            <div class="clearfix"></div>
                            <div align="center" class="d-print-block d-none">
                                <h3>{{school('name')}}</h3>
                                <h5>{{school('address')}}</h5>
                                <div class="clearhight50"></div>
                            </div>
                            <div class="page-panel-title w-100" style="margin-bottom: 15px">
                                @foreach($dues as $due)
                                    {{--<b>{{trans(school('country')->code == 'BD' ? ' Class' : 'Grade')}}</b>
                                    - {{$due->class->name}} &nbsp;--}}
                                    <b>@lang('Section')</b>
                                    - {{$due->class->name}}-{{$due->section->section_number}} &nbsp;
                                    <b>@lang('Student Name')</b>
                                    - {{$due->student->name}}
                                    @break($loop->first)
                                @endforeach
                                <span class="pull-right"><b>@lang('Student Due Report') {{$from}} @lang('to') {{$to}}</b></span>
                            </div>
                            @if($dues->count())
                                <div class="clearfix"></div>
                                <div class="table-responsive">
                                    <table class="table table-bordered  table-striped">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            {{--<th>Student Name</th>--}}
                                            <th>@lang('Head Name')</th>
                                            <th class="text-right">@lang('Total Due')</th>
                                            <th class="text-right">@lang('Paid')</th>
                                            <th class="text-right">@lang('Waiver')</th>
                                            <th class="text-right">@lang('Current Due')</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @php($totalDue=$totalPaid=$totalWaiver=$currentDue=0)
                                        @php($studentShow=true)
                                        @foreach($dues as $due)
                                            @php($totalDue += $due->totalDue)
                                            @php($totalPaid += $due->paid)
                                            @php($totalWaiver += $due->waiver)
                                            @php($currentDue += $due->due)
                                            <tr>
                                                <td>{{$loop->index +1}}</td>
                                                <td>{{$due->name}}</td>
                                                <td class="text-right">{{number_format($due->totalDue,2)}}</td>
                                                <td class="text-right">{{number_format($due->paid,2)}}</td>
                                                <td class="text-right">{{number_format($due->waiver,2)}}</td>
                                                <td class="text-right">{{number_format($due->due,2)}}</td>
                                            </tr>
                                        @endforeach
                                        <tr>
                                            <td class="text-right" colspan="2"><b>@lang('Total')</b></td>
                                            <td class="text-right"><b>{{number_format($totalDue,2)}}</b></td>
                                            <td class="text-right"><b>{{number_format($totalPaid,2)}}</b></td>
                                            <td class="text-right"><b>{{number_format($totalWaiver,2)}}</b></td>
                                            <td class="text-right"><b>{{number_format($currentDue,2)}}</b></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                                @push('script')
                                    <script>
                                        function printDiv() {
                                            currentDateTime("printTime");
                                            var divToPrint = document.getElementById('printDiv');
                                            var newWin = window.open('', 'Print-Window');
                                            newWin.document.open();
                                            newWin.document.write('<html><title>Student Fee Report {{ $from." to ".$to}}</title><link rel="stylesheet" href="{{ asset("css/vendors.css") }}" id="bootswatch-print-id"><body onload="window.print()"><style>@page {size: a4 portrait;}.label{border:none;}.clearhight50{clear:both;height:50px}</style>' + divToPrint.innerHTML + '</body></html>');
                                            newWin.document.close();
                                            setTimeout(function () {
                                                newWin.close();
                                            }, 100);
                                        }
                                    </script>
                                @endpush
                            @else
                                @lang('No Related Data Found.')
                            @endif
                            <div class="clearhight50"></div>
                            <div class="d-print-block d-none">
                                <div class="pull-left" align="center">
                                    ----------------------
                                    <div class="clearfix"></div>
                                    <span class="border_dot">
                                        @lang('Accountant')
                                    </span>
                                </div>
                                <div class="pull-right" align="center">
                                    ----------------------
                                    <div class="clearfix"></div>
                                    <span class="border_dot">
                                        @lang('Head Teacher')
                                    </span>
                                </div>
                            </div>
                            <div class="clearhight50"></div>
                            <div align="center" class="d-print-block d-none">Developed by : {{reseller()->name}}</div>
                        </div>
                    @endisset
                </div>
            </div>
        </div>
    </div>
@endsection
@push('script')
    <script>
        $(function () {
            $('.datepicker').datepicker({
                format: "dd-mm-yyyy",
                viewMode: "days",
                minViewMode: "days",
                autoclose: true
            });
        });
    </script>
    <script>
        $(function () {
            $('.select2').select2();
        });
    </script>
@endpush