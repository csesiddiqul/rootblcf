<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <title>{{$invoice->school['short_name']}} @lang('Money Receipt')</title>
    <link rel="stylesheet" media="print" href="{{asset('css/accounts-print.css')}}">
</head>
<body>

<style>

    * {
        margin: 0;
        padding: 0;
    }


    .full_con {
        display: inline-flex;
        list-style-type: none;
        margin: 0 auto;
    }

    .float-left {
        float: left !important;
    }

    .bor_r_d {
        border-right-style: dotted;
        border-right-width: thin;
        margin-right: 10px;
        padding-right: 10px;
    }

    #page {
        font-size: 12px;
        height: 624px;
        line-height: 18px;
        margin: 0 auto;
        width: 317px;

    }

    .con_margin {
        margin: 5px;
    }

    .con_margin1 {
        margin: 5px !important;

        padding-left: 0px !important;
        padding-right: 0px !important;
    }

    .font_10 {
        font-size: 10px;
    }

    .font_12 {
        font-size: 12px;
    }

    .font_13 {
        font-size: 14px;
    }

    .fl {
        float: left;
    }

    .fr {
        float: right;
    }

    .cb {
        clear: both;
    }

    .border_dot {
        border-bottom-style: dotted;
        border-bottom-width: thin;
        display: inline-block;
        width: 100%;
        margin-left: 1px;
    }

    .input {
        border: 1px solid #000;
    }

    .table {
        border-collapse: collapse;
        width: 100%;
    }

    /*.table td:first-child {
        width: 10%;
    }*/
    .li li {
        list-style-type: none;
        margin-left: 2px;
    }

    .li div {
        display: inline-table;
        text-align: right;
        width: 15px;
    }

    .box1 {
        box-sizing: border-box;
        width: 33%;
        float: left;
        text-align: center;

    }

    .mar_top25 {
        margin-top: 25px;
    }

    .head_bac {
        background-color: #000;
        border-radius: 10px;
        color: #fff;
        font-weight: bold;
        width: 150px;
    }

    .con_margin td, .con_margin th {
        vertical-align: top;
        padding-left: 2px;
        padding-right: 2px;
    }

    .slip-logo {
        text-align: center !important;
        /*padding: 18px 10px 14px 14px !important;*/
    }

    .slip-content {
        /*float:left;
    */
        padding: 0px 0px 10px 0px !important;
        width: 100%;
    }

    .underline {
        text-decoration: underline;

    }


    .acno {
        border-collapse: collapse;
        border: 1px solid black;
    }

    .acno tr {
        border-collapse: collapse;
        border: 1px solid black;
    }

    .acno tr td {
        border-collapse: collapse;
        border: 1px solid black;
    }

    .text-right {
        text-align: right;
    }

    .text-center {
        text-align: center;
    }

    .bor_r_d:last-of-type {
        border-right-style: none !important;
    }

    .mt-40 {
        margin-top: 40px;
    }

    .float-right {
        float: right !important;
    }

    .mb-20 {
        margin-bottom: 20px !important;
    }

    .mt-30 {
        margin-top: 30px !important;
    }

    .btn-info {
        background-color: #0077f7 !important;
        color: #fff !important;
    }

    .btn-info {
        background-color: #0077f7 !important;
        color: #fff !important;
    }

    .btn-sm {
        padding: 6px 9px;
        font-size: 13px;
        line-height: 1.5;
        border-radius: 3px;
        text-decoration: none;
        cursor: pointer;
    }

    .btn-outline-primary {
        color: #007bff;
        background-color: transparent;
        background-image: none;
        border-color: #007bff;
    }

    .btn-outline-primary:hover {
        color: #fff;
        background-color: #007bff;
        border-color: #007bff;
    }

    .btn-outline-success {
        color: #28a745;
        background-color: transparent;
        background-image: none;
        border-color: #28a745;
        border: 1px solid;
        margin-top: 10px !important;
    }

    .btn-outline-success:hover {
        color: #fff;
        background-color: #28a745;
        border-color: #28a745;
    }
</style>

<div class="first_div" style="width: 1025px !important; margin: 0 auto !important;" id="SelectorToPrint">
    @auth
        <a href="{{url()->previous()}}"
           class="btn btn-outline-success d-print-none float-right btn-sm ">@lang('Back')</a>
    @else
        <a href="{{route('pay_online')}}"
           class="btn btn-outline-success d-print-none float-right btn-sm ">@lang('Back')</a>
    @endauth
    <button class="printbtn btn  btn-outline-primary btn-sm"
            onclick="window.print()" style="margin-top: 10px !important;"
            role="button" id="btnPrint"><i class="fa fa-print"></i> @lang('Print')
    </button>
    <ul class="full_con">
        @for($j = 0;$j< foqas_setting('invoice_copy');$j++)
            <li class="bor_r_d">
                <div id="page">
                    <header>
                        <div align="center" class="con_margin">
                            @if (foqas_setting('logo_type') == 1)
                                @php $logo = foqas_setting('express'); @endphp
                                @empty($logo)
                                    @php $logo = 'https://foqasacademy.s3.us-east-2.amazonaws.com/img/01/favicon.png'; @endphp
                                @else
                                    <style>
                                        .img-fluid {
                                            width: 70% !important;
                                        }
                                    </style>
                                @endempty
                            @else
                                <style>
                                    .imga {
                                        width: 210px
                                    }

                                    .img-fluid {
                                        width: 100% !important;
                                        height: 40px;
                                    }
                                </style>
                                @php $logo = foqas_setting('standard'); @endphp
                                @empty($logo)
                                    @php $logo = 'https://foqasacademy.s3.us-east-2.amazonaws.com/img/01/icpl.png'; @endphp
                                @endempty
                            @endif
                            <div align="center" class="slip-content">
                                <h3 style="font-family: Myriad Pro;"><b>{{$invoice->school['name']}}</b></h3>
                                <p class="font_12 underline"><b>{{$invoice->school['address']}}</b></p>
                                <div class="slip-logo">
                                    <img class="img-fluid" src="{{$logo}}"
                                         style="width: 20% !important;margin-top: 2px !important;">
                                </div>
                                <p class="font_10"
                                   style="font-size: 14px !important; margin-bottom:8px !important;">{{$invoiceType[$j]}}</p>
                            </div>
                        </div>
                        <div class="con_margin1">
                            <div class="col-md-6" style="float: left;">

                                <table class="table  ">
                                    <tr>
                                        <td style="">@lang('MR') <span
                                                    class="float-right"> : </span></td>
                                        <td class="border_dot">{{$invoice->reciept_number}}</td>
                                    </tr>
                                    <tr>
                                        <td style="">@lang('Student ID') <span
                                                    class="float-right"> : </span></td>
                                        <td class="border_dot">{{$invoice->student['student_code']}}</td>
                                    </tr>
                                    @php $cName = school('country')->code == 'BD' ? 'Class' : 'Grade'; @endphp
                                    <tr>
                                        <td>@lang($cName.' & Section') <span
                                                    class="float-right"> : </span></td>
                                        <td class="border_dot">{{$invoice->student->section->class['name']}}
                                            - {{$invoice->student->section['section_number']}}</td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col-md-6 float-right">
                                <table class="table  ">
                                    <tr>
                                        <td>@lang('Date') <span
                                                    class="float-right">: </span></td>
                                        <td class="border_dot">{{date('d-m-Y',strtotime($invoice->trans_date))}}</td>
                                    </tr>
                                    <tr>
                                        <td>@lang('Session') <span
                                                    class="float-right">: </span></td>
                                        <td class="border_dot">@isset($invoice->student->studentInfo)
                                                {{getSessionById($invoice->student->studentInfo['session'],'schoolyear')}}
                                            @endisset</td>
                                    </tr>
                                    <tr>
                                        <td>@lang('Roll') <span
                                                    class="float-right">: </span></td>
                                        <td class="border_dot">{{$invoice->student->studentInfo['class_roll']}}</td>
                                    </tr>
                                </table>
                            </div>
                            <div class="clearfix" style="clear: both;"></div>
                            <div class="col-md-12" style="float: left;">
                                <table class="table  ">
                                    <tr>
                                        <td style="width: {{school('country')->code == 'BD' ? '80.69' : '84'}}px;">@lang('Student Name')
                                            <span
                                                    class="float-right">: </span></td>
                                        <td class="border_dot">{{$invoice->student['name']}}</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </header>
                    <div class="clearfix" style="clear: both;"></div>
                    <section>
                        <div class="con_margin">
                            <table class="table" border="1" style="font-family:Lucida sans;font-size:12px;">
                                <thead>
                                <tr>
                                    <th>
                                        <center> @lang('SL') </center>
                                    </th>
                                    <th>
                                        <center> @lang('Description') </center>
                                    </th>
                                    <th>
                                        <center> @lang('Taka') </center>
                                    </th>
                                    <th>
                                        <center> @lang('Waiver') </center>
                                    </th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $i = 1; ?>
                                @foreach($invoice->paymentDetail as $in)
                                    <tr>
                                        <td class="text-center">{{$i++}}</td>
                                        <td>{{$in->due->fee->account_sector["name"]}}</td>
                                        <td class="text-right">{{number_format($in["amount"],2)}}</td>
                                        <td class="text-right">{{number_format($in["waiver"],2)}}</td>
                                    </tr>
                                @endforeach
                                <tr>
                                    <td colspan="2">@lang('Sub Total')</td>
                                    <td class="text-right">{{number_format($invoice->total-$invoice->waiver,2)}}</td>
                                    <td class="text-right">{{number_format($invoice->waiver,2)}}</td>
                                </tr>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th colspan="2">@lang('Grand Total')</th>
                                    <th colspan="2"
                                        class="text-right">{{number_format($invoice->total-$invoice->waiver,2)}}</th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </section>
                    <footer>
                        <div class="con_margin">
                            <div>
                                @lang('In Words'): {{convertNumber($invoice->total-$invoice->waiver.'.00')}}. <span
                                        style="width: 256px;" class="border_dot"></span>
                            </div>
                            <!--<div>
                                Scroll No-
                                <input class="input" value="">
                            </div>
                            -->
                            <div class="cb"></div>
                            <div class="mt-30 ">
                                @php
                                    $headSign = foqas_setting('head_signature');
                                    if (empty($headSign)){
                                        $pad = 0;
                                    }else{
                                       $pad = '46px';
                                    }
                                @endphp
                                <div class="float-left" align="center"
                                     style="width: 33%;float: left; padding-top: {{$pad}} !important;">
                                    ----------------------
                                    <div class="clearfix "></div>
                                    <span class="">
                                        @lang('Accountant')
                                    </span>
                                </div>


                                <div class="float-right" align="center" style="width: 33%; float: left;">
                                    <img width="100%"
                                         src="{{$headSign}}"
                                         alt="Head Of the Institute">
                                    <div class="clearfix"></div>
                                    ----------------------
                                    <div class="clearfix cb"></div>
                                    <span class="">
                                        @lang('Head Of the Institute')
                                    </span>
                                </div>
                            </div>
                            {{-- <div class= "mt-60">
                                <div class="box1">Student's Signature</div>
                                <div class="box1">Cashier</div>
                                <div class="box1">Officer</div>
                                <div class="cb"></div>
                            </div> --}}
                        </div>
                        <div class="cb"></div>
                        <div class="mt-30"
                             style="font-family:Lucida sans;font-size:10px; text-align: center !important; margin-top: 30px;">
                            <p>Developed by: {{reseller()->name}}</p>
                        </div>
                    </footer>
                </div>
            </li>
        @endfor
    </ul>
</div>
{{--<script type="text/javascript">
    function printDiv(divName) {
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
    }
</script>--}}
</body>
</html>


